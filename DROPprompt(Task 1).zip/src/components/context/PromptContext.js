import { createContext } from "react";

const PromptContext = createContext()

export default PromptContext;